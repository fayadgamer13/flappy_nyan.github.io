# Welcome to the Game of Flappy Nyan

play it here
https://fayadgamer13.github.io/flappy_nyan.github.io

# How to Play

so basicly the game looks familar to the game of flappy bird but a nyan cat version and in the game you tap on the player to make it jump and past through the pipes and when the player falls or touches pipes it loses the game and if you get 30 sorce you get a buy a player

# Reporing Issues or Problem

in the game if you go to settings you will see a button that says " 📧 report a problem " when you click on it it takes you through google gmail or another gmail program such as outlook if you are a windows user
or you can email me the problem

* { wadifayad@gmail.com } *

# Note!
this is game is on beta and you might find some pink black gitches because it means te texture is messing which is not done or the texture not loading up.